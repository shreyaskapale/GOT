# Webfonts

Webfonts created from TrueType (TTF) by [Transfonter](https://transfonter.org).

| Font (Demo) | Author | License | Source |
|------|--------|---------|--------|
| [AvQest](https://grokify.github.io/webfonts/avqest/) | [Graham Meade](https://smartfonts.com/graham-meade.author) | [Freeware (Commercial Free) license](https://github.com/grokify/webfonts/blob/master/avqest/LICENSE.md) | [SmartFonts.com](https://smartfonts.com/avqest.font) |
| [Game of Thrones](https://grokify.github.io/webfonts/game-of-thrones/) | [Charlie-Jorge Samways](https://smartfonts.com/charlie-jorge-samways.author) | [Free for Commercial use license](https://github.com/grokify/webfonts/blob/master/game-of-thrones/LICENSE.md) | [SmartFonts.com](https://smartfonts.com/game-of-thrones.font) |
