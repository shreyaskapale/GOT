Free for Commercial use license

License type: Commercial Free

Free for both personal & commercial use. For more information [contact](https://charliesamways.carbonmade.com/contact) Charlie-Jorge Samways.