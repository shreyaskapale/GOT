Freeware (Commercial Free) license

License type: Commercial Free

Copyright (c) 1998 GemFonts 98 / Imitation Warehouse

Free for both personal & commercial use.
